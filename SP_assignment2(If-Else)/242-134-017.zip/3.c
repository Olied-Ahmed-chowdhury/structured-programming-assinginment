
#include<stdio.h>
int main(){
int a;
printf("input a number : ");
scanf("%d",&a);
int b;
printf("input b number : ");
scanf("%d",&b);
if(a==b){
    printf("both is equal");
}
else
    printf("not equal");
return 0;


}

