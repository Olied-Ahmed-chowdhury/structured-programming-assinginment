#include<stdio.h>
int main(){
int age;
printf("input person age : ");
scanf("%d",&age);
if(age<18){
    printf("he/she is not eligible for vote");
    }
else {
    printf("he/she eligible for vote");
     }
return 0;


}



