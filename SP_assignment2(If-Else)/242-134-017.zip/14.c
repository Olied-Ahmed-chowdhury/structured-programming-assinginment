
#include<stdio.h>
int main(){
char ch;
printf("enter a alphabet : ");
scanf("%c",&ch);
if ((ch>='a' && ch<='z') || (ch >='A' && ch <='Z')){
    printf("alphabet\n");
}
     else {
        printf("not an alphabet");
     }
return 0;


}




