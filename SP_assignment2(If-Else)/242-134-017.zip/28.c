
#include <stdio.h>
int main() {
    int a, b, c;
    printf("Enter the three sides of a triangle: ");
    scanf("%d %d %d", &a, &b, &c);
    if (a+b>c && b+c>a && c+a>b) {
        printf("valid triangle\n");
    } else {
        printf("invalid triangle\n");
    }
    return 0;
}
