
#include<stdio.h>
int main(){
int a;
printf("input a number : ");
scanf("%d",&a);
if(a%5==0 && a%6==0){
    printf("both 5 and 6 are factor");
    }
else {
    printf("both are not factor");
     }
return 0;


}


