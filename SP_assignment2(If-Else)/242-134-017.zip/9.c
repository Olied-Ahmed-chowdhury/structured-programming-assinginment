
#include<stdio.h>
int main(){
int a;
printf("input a number : ");
scanf("%d",&a);
int b;
printf("input b number : ");
scanf("%d",&b);
if(a>b){
    printf("bigger number is %d\n",a);
    }
else {
    printf("bigger number id %d",b);
     }
return 0;


}


