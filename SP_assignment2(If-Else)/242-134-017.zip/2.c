#include<stdio.h>
int main(){
int n;
printf("input a number : ");
scanf("%d",&n);
if(n<0){
    printf("negative");
}
else
    printf("non-negative");
return 0;


}

